import LoginPage from "../pages/Loginpage"

describe("Testing Login Functionality",()=>{

    const loginPage = new LoginPage();
    // To change the browser resolution for each test
    beforeEach(()=>{

        cy.viewport(1920,1080); // Maintaining resolution. 
    })
    // Test Case 1: Verify Login functionality using wrong username and correct password.

    it ("Testing with invalid Username",()=>{

        loginPage.userLogin("standard_user1","secret_sauce");
        loginPage.invalidAssertion();
        
  

    })

     // Test Case 2: Verify Login functionality using correct username and wrong password.

        it ("Testing with invalid Password",()=>{

   
            loginPage.userLogin("standard_user","secret_sauceQ");
            loginPage.invalidAssertion();        
    })


    // Test Case 3: Verify Login functionality using Wrong username and wrong password.
        it("Testing with invalid username and invalid password",()=>{

            loginPage.userLogin("WrongUserName","WrongPass");
            loginPage.invalidAssertion();

        })

    // Test Case 4 : Verify Login functionality using correct username and password.

    it("Testing with correct username and password",()=>{

        loginPage.userLogin("standard_user","secret_sauce");
        loginPage.textAssertion();

    })


})
