import LoginPage from "../pages/Loginpage"

import AddToCart from "../pages/AddtoCart"

describe("Testing adding product to the cart",()=>{
    const loginPage =new LoginPage();
    const addToCart =new AddToCart();


    before(()=>{
        loginPage.userLogin("standard_user","secret_sauce");
    })    
    it("User in dashboard,cart and checkout page",()=>{

        
        addToCart.viewProduct();
        addToCart.addingToCart();
        addToCart.goingToCartPage();
        addToCart.goingToCheckoutPage();
        addToCart.confirmCheckoutPage("Sabbir","Mridha","1250");
        addToCart.textAssertion();


    })


})