class AddToCart{
    
    viewProduct(){
        cy.get('[data-test="item-4-title-link"] > [data-test="inventory-item-name"]').click();
    } 

    addingToCart(){

        cy.get('[data-test="add-to-cart"]').click();
    }
    goingToCartPage(){

       cy.get('[data-test="shopping-cart-link"]').click();
    }
    goingToCheckoutPage(){

        cy.get('[data-test="checkout"]').click();
    }
    confirmCheckoutPage(firstname,lastname,zipcode){

        cy.get('[data-test="firstName"]').type(firstname);
        cy.get('[data-test="lastName"]').type(lastname);
        cy.get('[data-test="postalCode"]').type(zipcode);
        cy.get('[data-test="continue"]').click();
        cy.get('[data-test="finish"]').click();

    }textAssertion(){

        // Asertion for successful Submission of Order
        cy.get('[data-test="complete-header"]').should("have.text","Thank you for your order!");
    }


    
    
    
}
export default AddToCart;
