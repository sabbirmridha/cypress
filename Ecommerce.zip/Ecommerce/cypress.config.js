const { defineConfig } = require("cypress");

module.exports = defineConfig({
  video: true, // Enable video recording
  chromeWebSecurity: false,
  

  //reporter: 'cypress-mochawesome-reporter', // Added for mochawesome report generation.-->2
  
  e2e: {
     watchForFileChanges:false, 
    setupNodeEvents(on, config) {

    
    //require('cypress-mochawesome-reporter/plugin')(on); // Added for mochawesome report generation.-->1


      // defining priority for test cases-

      config.specPattern =[

        'cypress/e2e/Login.cy.js',
        'cypress/e2e/AddToCart.cy.js'
      ]

      
     
      // implement node event listeners here
    },
  },
});
